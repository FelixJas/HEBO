import dataclasses
import logging
import os
import re
import shutil
from dataclasses import dataclass
from typing import Callable

import jsonschema
from dataclasses_json import DataClassJsonMixin

PromptType = str | dict | list
FunctionCallType = dict
OutputType = str | FunctionCallType

import backoff

logger = logging.getLogger("aide")


@backoff.on_predicate(
    wait_gen=backoff.expo,
    max_value=60,
    factor=1.5,
)
def backoff_create(
        create_fn: Callable, retry_exceptions: list[Exception], *args, **kwargs
):
    try:
        return create_fn(*args, **kwargs)
    except retry_exceptions as e:
        logger.info(f"Backoff exception: {e}")
        return False


def opt_messages_to_list(
        system_message: str | None,
        user_message: str | None,
        convert_system_to_user: bool = False,
) -> list[dict[str, str]]:
    messages = []
    if system_message:
        if convert_system_to_user:
            messages.append({"role": "user", "content": system_message})
        else:
            messages.append({"role": "system", "content": system_message})
    if user_message:
        messages.append({"role": "user", "content": user_message})
    return messages


def compile_prompt_to_md(prompt: PromptType, _header_depth: int = 1) -> str:
    if isinstance(prompt, str):
        return prompt.strip() + "\n"
    elif isinstance(prompt, list):
        return "\n".join([f"- {s.strip()}" for s in prompt] + ["\n"])

    out = []
    header_prefix = "#" * _header_depth
    for k, v in prompt.items():
        out.append(f"{header_prefix} {k}\n")
        out.append(compile_prompt_to_md(v, _header_depth=_header_depth + 1))
    return "\n".join(out)


def fix_json_string(json_string: str) -> str:
    """
    Corrects a JSON-like string to conform to valid JSON.
    """
    # remove ```json at the beginning and ``` at the end if present
    json_string = re.sub(r"^```json\s*|\s*```$", "", json_string.strip())

    # remove Python-style comments (# ...)
    json_string = re.sub(r"#.*", "", json_string)

    # Remove JavaScript-style comments (// ...)
    json_string = re.sub(r"//.*", "", json_string)

    # replace single quotes with double quotes (both for keys and values)
    # json_string = re.sub(r"(?<!\\)'", '"', json_string)

    # any internal double quotes inside the value are properly escaped
    json_string = re.sub(r'(?<=:)\s*"(.*?)"\s*(?=[,\}\]])',
                         lambda match: '"{}"'.format(match.group(1).replace('"', r'\"')), json_string)

    # remove trailing commas that are not allowed in JSON
    json_string = re.sub(r",\s*(?=[}\]])", "", json_string)

    return json_string


def check_for_anomaly(json_data: dict, schema: dict) -> tuple[list[str], str]:
    required_keys = schema["required"]
    properties = schema["properties"]
    available_keys = list(json_data.keys())
    missing_keys = []

    error_message = ""
    for key in required_keys:
        if key in available_keys:
            if (properties[key].get("type") == "number" and not isinstance(json_data[key], (int, float, type(None)))) or \
                    (properties[key].get("type") == "boolean" and not isinstance(json_data[key], bool)) or \
                    (properties[key].get("type") == "string" and not isinstance(json_data[key], str)):
                error_message += f"Key '{key}' is not of type '{properties[key].get('type')}' \n"

        else:
            missing_keys.append(key)

    return missing_keys, error_message


@dataclass
class FunctionSpec(DataClassJsonMixin):
    name: str
    json_schema: dict  # JSON schema
    description: str

    def __post_init__(self):
        # validate the schema
        jsonschema.Draft7Validator.check_schema(self.json_schema)

    @property
    def as_openai_tool_dict(self):
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.json_schema,
            },
            "strict": True,
        }

    @property
    def openai_tool_choice_dict(self):
        return {
            "type": "function",
            "function": {"name": self.name},
        }


def get_terminal_width() -> int:
    # Get the terminal size
    width = int(os.getenv("SCREEN_WIDTH", shutil.get_terminal_size((80, 20)).columns))
    return width


def str_justify_one_line(s: str, w: int) -> list[str]:
    """
    Given a string containing a single-line input, return a list of strings of fixed length to allow single
    -column display
    """
    if s == "":
        return [" " * w]
    lines = []
    last_char = " "
    i = 0
    while i < len(s):
        new_line = ""
        if last_char.isalnum() and s[i].isalnum():
            new_line += "-"
        end = i + w - len(new_line)
        new_line += s[i:end]
        new_line += " " * (w - len(new_line))
        lines.append(new_line)
        i = end
        last_char = new_line[-1]
    return lines


def justify_text(text: str, w: int) -> list[str]:
    """ Given a text, get a list of strings such that the text can be printed in a column of fixed length"""
    all_lines = text.split("\n")
    justified_text = []
    for line in all_lines:
        aux_line = line.replace("｜", "|").replace("\t", "    ")
        justified_text.extend(str_justify_one_line(s=aux_line, w=w))
    return justified_text


def print_in_two_cols(t1: str, t2: str, w: int = 88) -> None:
    """ Given two texts, print them in parallel in two separate columns"""
    w = (w - 7) // 2
    col1 = justify_text(t1, w=w)
    col2 = justify_text(t2, w=w)
    max_lines = max(len(col1), len(col2))
    col1 = [" " * w for _ in range(max_lines - len(col1))] + col1
    col2 = [" " * w for _ in range(max_lines - len(col2))] + col2

    print("┌" + "─" * (w + 2) + "┬" + "─" * (w + 2) + "┐")
    for i in range(max_lines):
        print("│ " + col1[i] + " │ " + col2[i] + " │")
    print("└" + "─" * (w + 2) + "┴" + "─" * (w + 2) + "┘")


class HumanSupervisionAction:
    """ Type of action that a user can choose when user supervision is queried """
    keys: list[str]
    description: str


class HumanGuidanceAction(HumanSupervisionAction):
    """ Type of action that a user can choose when user supervision is queried """
    keys = ["g", "G"]
    description = ("Add indications at the end of the prompt and let the LLM generate "
                   "a new answer (previous indications will be overwritten).")


class HumanContinueAction(HumanSupervisionAction):
    keys = ["c", "C"]
    description = "Continue without changing LLM output."


class HumanResampleLLMAction(HumanSupervisionAction):
    keys = ["r", "R"]
    description = "Make the LLM generate a new response."


class HumanFixAction(HumanSupervisionAction):
    keys = ["f", "F"]
    description = "Fix the LLM raw output (this will trigger human editing mode)."


class HumanSeqPrintModeAction(HumanSupervisionAction):
    keys = ["h", "H"]
    description = "Print messages one after the other (easier to copy paste or for small window width)"


@dataclasses.dataclass
class HumanSupervisionChecker:
    allow_resampling: bool
    allow_guidance: bool
    allow_continue: bool
    allow_fix: bool
    allow_seq_print: bool
    length: int = 150

    def query_human(self) -> HumanSupervisionAction:
        """
            Let human interact with the system (user can decide to continue, fix LLM output, redo LLM generation, etc.)

            Returns:
                action: the action chosen by the user
            """
        lines = ["┌" + "─" * (self.length - 2) + "┐"]
        new_line = "│ [HUMAN SUPERVISION] Choose an option:"
        new_line += " " * (self.length - 1 - len(new_line)) + "│"
        lines.append(new_line)
        actions = self.get_actions()
        options = {}
        for action in actions:
            new_line = f"│ - {'/'.join(action.keys)}: {action.description}"
            new_line += " " * (self.length - 1 - len(new_line)) + "│"
            lines.append(new_line)
            for new_key in action.keys:
                assert new_key not in options, f"duplicate key {new_key} for {options[new_key]} and {action}"
                options[new_key] = action
        lines.append("└" + "─" * (self.length - 2) + "┘")
        print("\n".join(lines))
        control = ""
        while control not in options:
            control = input(f"Write the option ({'/'.join(options)}):").strip()
        return options[control]

    def get_actions(self) -> list[HumanSupervisionAction]:
        actions: list[HumanSupervisionAction] = []
        if self.allow_continue:
            actions.append(HumanContinueAction())
        if self.allow_fix:
            actions.append(HumanFixAction())
        if self.allow_resampling:
            actions.append(HumanResampleLLMAction())
        if self.allow_guidance:
            actions.append(HumanGuidanceAction())
        if self.allow_seq_print:
            actions.append(HumanSeqPrintModeAction())
        return actions


def human_input(allow_cancel: bool, w=150) -> str:
    stop_signal = "[STOP]"
    redo_flag = "[REDO]"
    cancel_flag = "[CANCEL]"

    lines = ["─" * w]
    text = ("Rules for manual input in terminal:\n"
            "- write as many lines as you want\n"
            f"- when you're done, put stop flag: {stop_signal}\n"
            f"- if you spot a mistake in a previous line and you want to retry, enter : {redo_flag}")
    if allow_cancel:
        text += f"\n- if you want to cancel manual input, enter cancel flag : {cancel_flag}"
    text_lines = justify_text(text=text, w=w - 4)
    text_lines = list(map(lambda t: f"| {t} |", text_lines))
    lines.extend(text_lines)
    lines.append("─" * w)

    print("\n".join(lines))

    done = False
    n_trial = 0
    reply = ""
    while not done:
        reply = ""
        output = input(f"\n===> Please {'re' if n_trial > 0 else ''}start your reply: ")
        if allow_cancel and cancel_flag in output:
            raise HumanInputCancelError()
        n_empty = 0
        while stop_signal not in output and redo_flag not in output:
            reply += output + "\n"
            output = input("")
            if allow_cancel and cancel_flag in output:
                raise HumanInputCancelError()
            if output == "":
                n_empty += 1
            else:
                n_empty = 0
            if n_empty > 5:
                print(f"When you're done, put stop flag: {stop_signal}")
        if redo_flag in output:
            continue

        output = output[:len(output) - len(stop_signal)]
        reply += output
        done = True
    print("===> End of edition mode, resume running <===")
    return reply


def human_view(parsed_response, query_func, messages, **kwargs) -> str:
    screen_width = get_terminal_width()
    response_to_display = ""
    prompt_to_display = ""
    raw_response_to_display = ""

    prompt_to_display += "================================================\n"
    prompt_to_display += "==================== PROMPT ====================\n"
    prompt_to_display += "================================================\n"
    for m in messages:
        prompt_to_display += f"[[ {m['role']} ]]\n"
        prompt_to_display += f"{m['content']}\n"

    raw_response_to_display += "====================================================\n"
    raw_response_to_display += "=================== RAW RESPONSE ===================\n"
    raw_response_to_display += "====================================================\n"
    raw_response_to_display += parsed_response + "\n"

    response_to_display += "=======================================================\n"
    response_to_display += "=================== PARSED RESPONSE ===================\n"
    response_to_display += "=======================================================\n"
    response_to_display += str(parsed_response)
    print_in_two_cols(t1=prompt_to_display, t2=response_to_display, w=screen_width)

    human_supervision_handler = HumanSupervisionChecker(
        allow_fix=True, allow_continue=True, allow_resampling=True, allow_guidance=True, allow_seq_print=True,
        length=screen_width - 1
    )

    while True:
        action = human_supervision_handler.query_human()

        if isinstance(action, HumanSeqPrintModeAction):
            human_supervision_handler.allow_seq_print = False
            print(prompt_to_display)
            print(response_to_display)
            action = human_supervision_handler.query_human()

        if isinstance(action, HumanContinueAction):
            print("Continuing!\n")
            break
        elif isinstance(action, HumanFixAction):
            print("Get human fix!")
            try:
                fixed_reply = human_input(allow_cancel=True, w=screen_width)
            except HumanInputCancelError:
                print("Cancel human fix!")
                continue
            raw_output_text = fixed_reply
            parsed_response = raw_output_text
            break
        elif isinstance(action, HumanResampleLLMAction):
            print("Get a new answer!")
            return query_func(messages=messages, **kwargs)
        elif isinstance(action, HumanGuidanceAction):
            print("Provide guidance to get a better answer!")
            try:
                guidance = "\n" + human_input(allow_cancel=True, w=screen_width)
            except HumanInputCancelError:
                print("Cancel human guidance!")
                continue
            last_content = messages[-1]["content"]
            last_content += guidance
            messages[-1]["content"] = last_content
            return query_func(messages=messages, **kwargs)
        else:
            raise ValueError(action)

    return parsed_response


class HumanInputCancelError(Exception):
    pass


class LLMRetryManager:
    def __init__(self):
        self.retry_elapsed_time = 0

    def custom_before_sleep(self, retry_state):
        if retry_state.outcome.failed:
            exception = retry_state.outcome.exception()
            logger.warning(f"LLM Retrying... Attempt {retry_state.attempt_number} failed with "
                           f"time taken {retry_state.seconds_since_start}. Error: {str(exception)}")
            self.retry_elapsed_time = retry_state.seconds_since_start

    @property
    def elapsed_time(self) -> int:
        return int(self.retry_elapsed_time)

    def reset_elapsed_time(self):
        self.retry_elapsed_time = 0
