import atexit
import json
import logging
import os
import re
import shutil
import sys
import time
from datetime import datetime
from pathlib import Path

from aide.utils.metric import MetricValue
from . import backend

from .agent import Agent
from .interpreter import Interpreter
from .journal import Journal, Node
from omegaconf import OmegaConf
from rich.columns import Columns
from rich.console import Group
from rich.padding import Padding
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    TextColumn,
    TimeRemainingColumn,
)
from rich.text import Text
from rich.markdown import Markdown
from rich.status import Status
from rich.tree import Tree
from .utils.config import load_task_desc, prep_agent_workspace, save_run, load_cfg
import multiprocessing as mp


class VerboseFilter(logging.Filter):
    """
    Filter (remove) logs that have verbose attribute set to True
    """

    def filter(self, record):
        return not (hasattr(record, "verbose") and record.verbose)


def journal_to_rich_tree(journal: Journal):
    best_node = journal.get_best_node()

    def append_rec(node: Node, tree):
        if node.is_buggy:
            s = "[red]◍ bug"
        else:
            style = "bold " if node is best_node else ""

            if node is best_node:
                s = f"[{style}green]● {node.metric.value:.3f} (best)"
            else:
                s = f"[{style}green]● {node.metric.value:.3f}"

        subtree = tree.add(s)
        for child in node.children:
            append_rec(child, subtree)

    tree = Tree("[bold blue]Solution tree")
    for n in journal.draft_nodes:
        append_rec(n, tree)
    return tree


def journal_to_string_tree(journal: Journal) -> str:
    best_node = journal.get_best_node()
    tree_str = "Solution tree\n"

    def append_rec(node: Node, level: int):
        nonlocal tree_str
        indent = "  " * level
        if node.is_buggy:
            s = f"{indent}◍ bug (ID: {node.id})\n"
        else:
            # support for multiple markers; atm only "best" is supported
            markers = []
            if node is best_node:
                markers.append("best")
            marker_str = " & ".join(markers)
            if marker_str:
                s = f"{indent}● {node.metric.value:.3f} ({marker_str}) (ID: {node.id})\n"
            else:
                s = f"{indent}● {node.metric.value:.3f} (ID: {node.id})\n"
        tree_str += s
        for child in node.children:
            append_rec(child, level + 1)

    for n in journal.draft_nodes:
        append_rec(n, 0)

    return tree_str


def extract_node_dict_from_log(log_path: str) -> dict:
    extracted_dict = {}
    with open(log_path, "r") as f:
        log_data = f.read()

    dict_pattern = re.search(r"---Finally, the full journal of the run---\n({.*})", log_data, re.DOTALL)

    if dict_pattern:
        dict_str = dict_pattern.group(1)
        try:
            extracted_dict = json.loads(dict_str)
        except Exception as e:
            print(f"Error while parsing dictionary: {e}")
    else:
        print("No dictionary found in the log data.")

    return extracted_dict


def create_available_node_tree(journal: Journal, journal_json_path: str) -> None:
    """
    Recreate all already created nodes
    """
    if os.path.getsize(journal_json_path) == 0:
        return

    with open(journal_json_path, 'r') as file:
        node_dict = json.load(file)
        # node_dict = extract_node_dict_from_log(log_path=log_path)
        for node in node_dict["nodes"]:
            metric_json = node["metric"] if node["metric"] else None
            if metric_json:
                metric = MetricValue(value=metric_json["value"], maximize=metric_json["maximize"])
            else:
                metric = None
            node = Node(
                code=node["code"],
                plan=node["plan"],
                step=int(node["step"]),
                id=node["id"],
                ctime=float(node["ctime"]),
                _term_out=node["_term_out"],
                exec_time=float(node["exec_time"]),
                exc_type=node["exc_type"],
                exc_info=node["exc_info"] if node["exc_info"] else None,
                exc_stack=node["exc_stack"],
                analysis=node["analysis"],
                metric=metric,
                is_buggy=bool(node["is_buggy"]),
            )
            journal.append(node)

        node2parent = node_dict["node2parent"]
        for node_id in node2parent:
            node = journal.get_node(node_id)
            node.parent = journal.get_node(node2parent[node_id])
            node.parent.children.add(node)


def get_time_span_from_log(start_time_log: str, end_time_log: str):
    start_match = re.search(r'\[(.*?)\]', start_time_log)
    end_match = re.search(r'\[(.*?)\]', end_time_log)
    if start_match and end_match:
        start_time_str = start_match.group(1)
        start_time = datetime.strptime(start_time_str, "%Y-%m-%d %H:%M:%S,%f")

        end_time_str = end_match.group(1)
        end_time = datetime.strptime(end_time_str, "%Y-%m-%d %H:%M:%S,%f")

    else:
        raise "Could not extract time from the log provided"

    time_difference = (end_time - start_time).total_seconds()

    end_time = end_time.hour * 3600 + end_time.minute * 60 + end_time.second

    return time_difference, end_time


def previous_run_time_taken(log_path: str) -> tuple[int, int]:
    with open(log_path, 'r') as f:
        log_data = f.readlines()
        start_log = log_data[0]
        end_log = None
        total_time_span = 0
        for line in log_data[1:]:
            if "Resuming run" in line:
                if start_log is not None and end_log is not None:
                    time_span, end_time = get_time_span_from_log(start_time_log=start_log, end_time_log=end_log)
                    total_time_span += time_span
                    start_log = line
                    end_log = None
                else:
                    start_log = line
                    end_log = None
            else:
                match = re.search(r'\[(.*?)\]', line)
                if match:
                    end_log = line

        if start_log is not None and end_log is not None:
            time_span, end_time = get_time_span_from_log(start_time_log=start_log, end_time_log=end_log)
            total_time_span += time_span

        return int(total_time_span), int(end_time)


def update_best_gen_file(best_gen_time_file_path: str, end_time: int) -> None:
    if os.path.exists(best_gen_time_file_path):
        with open(best_gen_time_file_path, "r") as f:
            best_gen_time = f.read()
        relative_best_gen_time = time.time() - (end_time - float(best_gen_time))
        with open(best_gen_time_file_path, "w") as f:
            f.write(str(relative_best_gen_time))


def calculate_hf_retry_time(hf_time_file: str):
    hf_retry_time = 0
    if os.path.exists(hf_time_file):
        with open(hf_time_file, 'r') as f:
            time_wasted = json.load(f)
            for key in time_wasted:
                hf_retry_time += float(time_wasted[key])

    return int(hf_retry_time)


def run():
    cfg = load_cfg()

    journal = Journal()

    previous_run_time = 0
    if cfg.resume:
        # with Status("Resuming from previous run..."):
        aide_log_path = os.path.join(cfg.previous_log_path, "aide.log")
        previous_run_time, end_time = previous_run_time_taken(aide_log_path)

        cfg.agent.time_limit = cfg.agent.time_limit - previous_run_time
        cfg.workspace_dir = cfg.previous_workspace_path
        cfg.log_dir = Path(cfg.previous_log_path)
        best_gen_time_file_path = os.path.join(cfg.workspace_dir, cfg.agent.best_gen_time_file)
        update_best_gen_file(best_gen_time_file_path, end_time)
        full_log_path = os.path.join(cfg.previous_log_path, "journal.json")
        create_available_node_tree(journal, full_log_path)

    else:
        with Status("Preparing agent workspace (copying and extracting files) ..."):
            prep_agent_workspace(cfg)

    assert not os.path.exists(cfg.workspace_dir.parent/'failed.txt'), f"{cfg.workspace_dir.parent}/'failed.txt' exist"


    # dont want info logs from httpx
    httpx_logger: logging.Logger = logging.getLogger("httpx")
    httpx_logger.setLevel(logging.WARNING)

    logger = logging.getLogger("aide")

    log_format = "[%(asctime)s] %(levelname)s: %(message)s"
    logging.basicConfig(
        level=getattr(logging, cfg.log_level.upper()), format=log_format, handlers=[]
    )

    # save logs to files as well, using same format
    cfg.log_dir.mkdir(parents=True, exist_ok=True)

    # we'll have a normal log file and verbose log file. Only normal to console
    file_handler = logging.FileHandler(cfg.log_dir / "aide.log")
    file_handler.setFormatter(logging.Formatter(log_format))
    file_handler.addFilter(VerboseFilter())

    verbose_file_handler = logging.FileHandler(cfg.log_dir / "aide.verbose.log")
    verbose_file_handler.setFormatter(logging.Formatter(log_format))

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(logging.Formatter(log_format))
    console_handler.addFilter(VerboseFilter())

    logger.addHandler(file_handler)
    logger.addHandler(verbose_file_handler)
    logger.addHandler(console_handler)

    if cfg.resume:
        logger.info(f'Resuming run "{cfg.exp_name}"')
        logger.info(f"Previous run time: {previous_run_time}")
    else:
        logger.info(f'Starting run "{cfg.exp_name}"')

    task_desc = load_task_desc(cfg)
    task_desc_str = backend.compile_prompt_to_md(task_desc)

    def cleanup():
        if global_step == 0:
            shutil.rmtree(cfg.workspace_dir)

    atexit.register(cleanup)

    agent = Agent(
        task_desc=task_desc,
        cfg=cfg,
        journal=journal,
    )
    if cfg.resume:
        hf_retry_time = calculate_hf_retry_time(agent.hf_time_file)
        logger.info(f"Model retry elapsed time adjusted: {hf_retry_time}")
        agent.acfg.time_limit += hf_retry_time
        assert cfg.agent.time_limit > 0 , f"Allocated time {cfg.agent.time_limit} already passed!"

    interpreter = Interpreter(
        cfg.workspace_dir, **OmegaConf.to_container(cfg.exec)  # type: ignore
    )

    global_step = len(journal)
    prog = Progress(
        TextColumn("[progress.description]{task.description}"),
        BarColumn(bar_width=20),
        MofNCompleteColumn(),
        TimeRemainingColumn(),
    )
    status = Status("[green]Generating code...")
    prog.add_task("Progress:", total=cfg.agent.steps, completed=global_step)

    def exec_callback(*args, **kwargs):
        status.update("[magenta]Executing code...")
        res = interpreter.run(*args, **kwargs)
        status.update("[green]Generating code...")
        return res

    def generate_live():
        tree = journal_to_rich_tree(journal)
        prog.update(prog.task_ids[0], completed=global_step)

        file_paths = [
            f"Result visualization:\n[yellow]▶ {str((cfg.log_dir / 'tree_plot.html'))}",
            f"Agent workspace directory:\n[yellow]▶ {str(cfg.workspace_dir)}",
            f"Experiment log directory:\n[yellow]▶ {str(cfg.log_dir)}",
        ]
        left = Group(
            Panel(Text(task_desc_str.strip()), title="Task description"),
            prog,
            status,
        )
        right = tree
        wide = Group(*file_paths)

        return Panel(
            Group(
                Padding(wide, (1, 1, 1, 1)),
                Columns(
                    [Padding(left, (1, 2, 1, 1)), Padding(right, (1, 1, 1, 2))],
                    equal=True,
                ),
            ),
            title=f'[b]AIDE is working on experiment: [bold green]"{cfg.exp_name}[/b]"',
            subtitle="Press [b]Ctrl+C[/b] to stop the run",
        )

    while global_step < cfg.agent.steps:
        try:
            remaining_time = agent.time_limit - (time.time() - agent.start_time)
            no_time_remaining = remaining_time <= 0
            if no_time_remaining:
                logger.info(f'Time allocated exhausted,no_time_remaining: {no_time_remaining}, exiting')
                break
            interpreter.timeout = min(interpreter.timeout, remaining_time)
            agent.step(exec_callback=exec_callback)
            # on the last step, print the tree
            if global_step == cfg.agent.steps - 1:
                logger.info(journal_to_string_tree(journal))
            save_run(cfg, journal)
            global_step = len(journal)
            interpreter.cleanup_session()
        except Exception as e:
            interpreter.cleanup_session()
            raise e


if __name__ == "__main__":
    mp.set_start_method("spawn", force=True)
    run()
