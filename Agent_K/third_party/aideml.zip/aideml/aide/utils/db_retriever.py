import multiprocessing

from aide.utils.db_faiss import KaggleCompetitionDB


class KaggleCompetitionRetriever:
    def __init__(self, db: KaggleCompetitionDB, k: int = 4, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.db = db
        self.k = k

    def get_relevant_documents(self, query: str, competition_name: str) -> list[tuple[str, float, str]]:
        """
        Retrieves top-k similar competitions from db
        Args:
            query: Query string to do similarity search
            competition_name: Competition name

        Returns:

        """
        results = self.db.search_similar(query, k=self.k, competition_name=competition_name)
        return results


def _rag_worker(q: multiprocessing.Queue, task_desc, exp_name, search_k) -> None:
    """
    Worker function run in a subprocess
    Args:
        q: Queue to keep retrieved documents
        task_desc: Description of the task
        exp_name: Competition name
        search_k: Number of documents to be retrieved

    Returns:

    """
    db = KaggleCompetitionDB(db_path="kaggle_db")
    retriever = KaggleCompetitionRetriever(db, k=search_k)
    docs = retriever.get_relevant_documents(query=task_desc, competition_name=exp_name)
    q.put(docs)


def get_relevant_documents(
        task_desc: str, exp_name: str, search_k: int, timeout: int = 600
) -> list[tuple[str, float], str]:
    """
    Run RAG in a subprocess and return documents
    Args:
        task_desc: Description of the task
        exp_name: Competition name
        search_k: Number of documents to be retrieved
        timeout: Timeout in seconds

    Returns:

    """
    q = multiprocessing.Queue()
    p = multiprocessing.Process(
        target=_rag_worker,
        args=(q, task_desc, exp_name, search_k),
    )
    p.start()

    try:
        print("[RAG] Waiting to get details...", flush=True)
        docs = q.get(timeout=timeout)
    except Exception as e:
        p.terminate()
        raise TimeoutError("RAG subprocess timed out or failed to return data") from e

    p.join()

    if p.exitcode != 0:
        raise RuntimeError(f"RAG subprocess failed with exit code {p.exitcode}")

    return docs


if __name__ == "__main__":
    multiprocessing.set_start_method("spawn", force=True)
    task_desc = "Image classification"
    exp_name = "5-flowers-image-classification"
    db = KaggleCompetitionDB(db_path="kaggle_db")
    retriever = KaggleCompetitionRetriever(db, k=2)
    docs = retriever.get_relevant_documents(query=task_desc, competition_name=exp_name)
    print(f'Docs retrieved in normal flow: {len(docs)}')
    docs_process = get_relevant_documents(task_desc, exp_name, 2, timeout=3000)
    print(f'Docs retrieved in sub process flow: {len(docs_process)}')
    print(docs_process)
