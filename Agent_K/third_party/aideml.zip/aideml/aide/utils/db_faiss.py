import argparse
import os

from langchain.schema import Document
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings


class KaggleCompetitionDB:
    def __init__(self, model_name: str = "sentence-transformers/all-mpnet-base-v2", db_path: str = "kaggle_db"):
        """
        Initialize the FAISS database and the embeddings model.

        Args:
            model_name: Name of the model to use for embeddings.
            db_path: Path to save and load the database.
        """
        self.embeddings_model = HuggingFaceEmbeddings(model_name=model_name)
        self.db_path = db_path
        self.db = None

        self.load_db()

    def _db_exists(self) -> bool:
        """
        Check if the database exists at the specified path.

        return: True if the database exists, False otherwise.
        """
        return os.path.exists(self.db_path)

    def load_db(self) -> None:
        """
        Load the database if it exists.
        """
        if self._db_exists():
            self.db = FAISS.load_local(self.db_path, self.embeddings_model, allow_dangerous_deserialization=True)

    def add_competition(self, description: str, competition_name: str) -> None:
        """
        Add a competition description and tips to the database.

        Args:
            description: Summary of competition description.
            competition_name: Name of the competition.
        """
        # Create the document with metadata
        document = Document(page_content=description, metadata={'competition_name': competition_name})

        if self.db is None:
            self.db = FAISS.from_documents([document], self.embeddings_model)
        else:
            # Add the new document (competition description)
            self.db.add_documents([document])

    def save_db(self) -> None:
        """
        Save the database to the specified path.
        """
        self.db.save_local(self.db_path)

    def search_similar(self, query: str, k: int, competition_name: str) -> list[tuple[str, float, str]]:
        """
        Search for the top-k similar competitions.
        Args:
            query: Query string to do similarity search
            k: Number of documents to be retrieved
            competition_name: Competition name

        Returns: List of tuples containing (description, sim score and  comp name) of the top-k similar competitions.

        """
        docs_with_scores = self.db.similarity_search_with_score(query, k)
        results = [
            (doc.page_content, float(score), doc.metadata.get('competition_name')) for doc, score in docs_with_scores if
            doc.metadata.get('competition_name') != competition_name
        ]

        return results


def populate_db(db: KaggleCompetitionDB, comp_details_path: str) -> None:
    """
    Populate the database from specified directory containing data.
    Args:
        db: Database to populate.
        comp_details_path: Directory containing competition details.

    Returns:

    """
    # Iterate through competition directories
    for competition in os.listdir(comp_details_path):
        competition_path = os.path.join(comp_details_path, competition)

        if os.path.isdir(competition_path):
            # Process summary and technical reports directories
            for subdir in ['notebook_summaries', 'technical_reports']:
                subdir_path = os.path.join(competition_path, subdir)

                if os.path.isdir(subdir_path):
                    # Iterate through .txt files in the subdirectory
                    for txt_file in os.listdir(subdir_path):
                        if txt_file.endswith('.txt'):
                            # Check if it's a .txt file
                            txt_file_path = os.path.join(subdir_path, txt_file)

                            with open(txt_file_path, 'r') as file:
                                file_content = file.read()

                                # Add content to the database with the competition name as metadata
                                try:
                                    db.add_competition(file_content, competition)
                                except Exception as e:
                                    print(f"Error processing {txt_file_path} for competition {competition}: {e}")

    db.save_db()


def display_database_contents(db: KaggleCompetitionDB) -> None:
    for i in range(len(db.db.index_to_docstore_id)):
        doc = db.db.docstore.search(db.db.index_to_docstore_id[i])
        print(f"Item: {i}")
        print(f"Description: {doc.page_content}\n{doc.metadata}")


if __name__ == "__main__":
    """
    Populate the database from specified directory containing data.
    Example:
            python aide/utils/db_faiss.py
            python aide/utils/db_faiss.py --populate --data_path <path/to/collected_data>
    """

    parser = argparse.ArgumentParser(description="Kaggle Competition DB")
    parser.add_argument('--populate', action='store_true', help='Populate the database with data')
    parser.add_argument('--data_path', type=str, help='Path to the competition descriptions')

    args = parser.parse_args()

    db = KaggleCompetitionDB(db_path="kaggle_db")

    if args.populate:
        if not args.data_path:
            parser.error("--populate requires --data_path to be specified")
        else:
            print(f"Populating database from {args.data_path}")
            populate_db(db=db, comp_details_path=args.data_path)

    if os.path.exists('kaggle_db'):
        display_database_contents(db)
    else:
        print("No database found. Populate the database using the command "
              "`python aide/utils/db_faiss.py --populate --data_path <path/to/collected_data>`")
