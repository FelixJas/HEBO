"""configuration and setup utils"""
import glob
from dataclasses import dataclass
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Hashable, cast

import coolname
import rich
from omegaconf import OmegaConf
from rich.syntax import Syntax
import shutup
from rich.logging import RichHandler
import logging
import subprocess

from aide.journal import Journal, filter_journal

from . import tree_export
from . import copytree, preproc_data, serialize

shutup.mute_warnings()
logger = logging.getLogger("aide")

""" these dataclasses are just for type hinting, the actual config is in config.yaml """


@dataclass
class StageConfig:
    model: str
    temp: float


@dataclass
class SearchConfig:
    max_debug_depth: int
    debug_prob: float
    num_drafts: int


@dataclass
class AgentConfig:
    steps: int
    time_limit: int
    k_fold_validation: int
    expose_prediction: bool
    data_preview: bool
    convert_system_to_user: bool
    obfuscate: bool
    best_gen_time_file: str

    code: StageConfig
    feedback: StageConfig

    search: SearchConfig

    use_agent_k_warm_start: bool = False
    agent_k_submissions: Path | str | None = None

    use_rag: bool = False


@dataclass
class ExecConfig:
    timeout: int
    agent_file_name: str
    format_tb_ipython: bool


@dataclass
class Config(Hashable):
    data_dir: Path
    desc_file: Path | None

    goal: str | None
    eval: str | None

    log_dir: Path
    log_level: str
    workspace_dir: Path

    preprocess_data: bool
    copy_data: bool

    exp_name: str

    top_n: int

    resume: bool
    previous_log_path: str
    previous_workspace_path: str

    exec: ExecConfig
    agent: AgentConfig


def _get_next_logindex(dir: Path) -> int:
    """Get the next available index for a log directory."""
    max_index = -1
    for p in dir.iterdir():
        try:
            if current_index := int(p.name.split("-")[0]) > max_index:
                max_index = current_index
        except ValueError:
            pass
    return max_index + 1


def _load_cfg(
        path: Path = Path(__file__).parent / "config.yaml", use_cli_args=True
) -> Config:
    cfg = OmegaConf.load(path)
    if use_cli_args:
        cfg = OmegaConf.merge(cfg, OmegaConf.from_cli())
    return cfg


def load_cfg(path: Path = Path(__file__).parent / "config.yaml") -> Config:
    """Load config from .yaml file and CLI args, and set up logging directory."""
    return prep_cfg(_load_cfg(path))


def prep_cfg(cfg: Config):
    if cfg.data_dir is None:
        raise ValueError("`data_dir` must be provided.")

    # if cfg.desc_file is None and cfg.goal is None:
    #     raise ValueError(
    #         "You must provide either a description of the task goal (`goal=...`) or a path to a plaintext file containing the description (`desc_file=...`)."
    #     )

    if cfg.data_dir.startswith("example_tasks/"):
        cfg.data_dir = Path(__file__).parent.parent / cfg.data_dir
    cfg.data_dir = Path(cfg.data_dir).resolve()

    # if cfg.desc_file is not None:
    #     cfg.desc_file = Path(cfg.desc_file).resolve()

    top_log_dir = Path(cfg.log_dir).resolve()
    top_log_dir.mkdir(parents=True, exist_ok=True)

    top_workspace_dir = Path(cfg.workspace_dir).resolve()
    top_workspace_dir.mkdir(parents=True, exist_ok=True)

    # generate experiment name and prefix with consecutive index
    cfg.exp_name = cfg.exp_name or coolname.generate_slug(3)

    date = datetime.now().strftime("%Y-%m-%d-%H-%M-%S")

    # cfg.log_dir = (top_log_dir / cfg.exp_name / date).resolve()

    cfg.workspace_dir = (top_workspace_dir / cfg.exp_name / date).resolve()

    cfg.log_dir = (cfg.workspace_dir / 'run_logs' / date).resolve()

    # validate the config
    cfg_schema: Config = OmegaConf.structured(Config)
    cfg = OmegaConf.merge(cfg_schema, cfg)

    return cast(Config, cfg)


def print_cfg(cfg: Config) -> None:
    rich.print(Syntax(OmegaConf.to_yaml(cfg), "yaml", theme="paraiso-dark"))


def get_hardware_info():
    try:
        cuda_visible_devices = os.environ.get("CUDA_VISIBLE_DEVICES")
        if cuda_visible_devices:
            visible_devices = cuda_visible_devices.split(",")
            if not visible_devices[0].strip():
                return "a CPU"

        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=True
        )
        all_gpus = result.stdout.strip().split("\n")

        if cuda_visible_devices:
            # Filter GPUs based on CUDA_VISIBLE_DEVICES
            indices = list(map(int, visible_devices))
            gpus = [all_gpus[i] for i in indices]
        else:
            gpus = all_gpus

        if gpus:
            from collections import Counter
            gpu_count = Counter(gpus)
            return ", ".join(f"{count} {gpu}" for gpu, count in gpu_count.items())
        else:
            return "a CPU"
    except (FileNotFoundError, subprocess.CalledProcessError):
        return "a CPU"
    except IndexError:
        return "a CPU"
    except Exception as e:
        return "a CPU"


def prepare_notes(cfg: Config):
    notes = [
        f"\nBENCHMARK INSTRUCTIONS\n\n",
        f"First, please read the instructions below\n",
        f"- **Competition-specific instructions**: Competition specific descriptions will be provided.\n",
        f"- **Dataset**: The dataset files for the competition are available in `{cfg.data_dir}`."
        f"Test dataset does not contain any targets.\n",
        f"- **Submission**: You can find sample submission format inside `{cfg.data_dir}` as specified `Data Overview."
        f"Always use same 'id' available inside sample submission file. You are not allowed to change 'id'."
        f"Based on sample submission file you have to generate submission.csv for the test data.\n",
        f"- **Cheating**: You are not allowed to view others' solutions to this competition. "
        f"If we detect that your submission is plagiarized from others, the submission will be disqualified.\n\n",
        f"Wherever there is a conflict between the points above and the competition-specific instructions, "
        f"competition points always takes priority.\n\n",
        f"Your submission will be graded based on the metric in the competition-specific instructions. "
        f"Your goal is to achieve the best score possible on the competition task.\n\n"
    ]
    return notes


def prepare_additional_notes(cfg: Config):
    additional_notes = [
        "\nADDITIONAL NOTES\n\n",
        f"**Compute**: You have access to {get_hardware_info()} with the appropriate drivers installed.\n",
        f"**Total Runtime**: You have a maximum of {cfg.agent.time_limit} seconds to attempt this task. You may "
        f"iteratively develop your solution within this time frame, but bear in mind that program runtime also "
        f"counts towards this limit.\n",
        f"**Total Steps**: You have a maximum of {cfg.agent.steps} steps to submit your solution.\n",
        f"You will be informed of the remaining time and steps at each step\n.",
        f"**Use as much of the available time as possible to refine and optimize your submission**: Your goal is to "
        "achieve the best possible score, not just to submit your first working solution.\n"

    ]

    return additional_notes


def load_task_desc(cfg: Config):
    """Load task description from markdown file or config str."""

    # either load the task description from a file
    # if cfg.desc_file is not None:
    #     if not (cfg.goal is None and cfg.eval is None):
    #         logger.warning(
    #             "Ignoring goal and eval args because task description file is provided."
    #         )
    #
    #     with open(cfg.desc_file) as f:
    #         notes = f.read()
    notes = "".join(prepare_notes(cfg))
    additional_notes = "".join(prepare_additional_notes(cfg))

    return notes + additional_notes

    # # or generate it from the goal and eval args
    # if cfg.goal is None:
    #     raise ValueError(
    #         "`goal` (and optionally `eval`) must be provided if a task description file is not provided."
    #     )
    #
    # task_desc = {"Task goal": cfg.goal}
    # if cfg.eval is not None:
    #     task_desc["Task evaluation"] = cfg.eval
    #
    # return task_desc


def prep_agent_workspace(cfg: Config):
    """Setup the agent's workspace and preprocess data if necessary."""
    (cfg.workspace_dir / "input").mkdir(parents=True, exist_ok=True)
    (cfg.workspace_dir / "working").mkdir(parents=True, exist_ok=True)
    (cfg.workspace_dir / "submission").mkdir(parents=True, exist_ok=True)
    copytree(cfg.data_dir, cfg.workspace_dir / "input", use_symlinks=not cfg.copy_data)
    if cfg.preprocess_data:
        preproc_data(cfg.workspace_dir / "input")


def save_run(cfg: Config, journal: Journal):
    cfg.log_dir.mkdir(parents=True, exist_ok=True)

    filtered_journal = filter_journal(journal)
    # save journal
    serialize.dump_json(journal, cfg.log_dir / "journal.json")
    serialize.dump_json(filtered_journal, cfg.log_dir / "filtered_journal.json")
    # save config
    OmegaConf.save(config=cfg, f=cfg.log_dir / "config.yaml")
    # create the tree + code visualization
    # only if the journal has nodes
    if len(journal) > 0:
        tree_export.generate(cfg, journal, cfg.log_dir / "tree_plot.html")
    # save the best found solution
    best_node = journal.get_best_node()
    if best_node is not None:
        with open(cfg.log_dir / "best_solution.py", "w") as f:
            f.write(best_node.code)
    # concatenate logs
    with open(cfg.log_dir / "full_log.txt", "w") as f:
        f.write(
            concat_logs(
                chrono_log=cfg.log_dir / "aide.log",
                best_node=cfg.workspace_dir / "best_solutions" / "solution_*" / "node_id.txt",
                journal=cfg.log_dir / "filtered_journal.json",
            )
        )


def concat_logs(chrono_log: Path, best_node: Path, journal: Path):
    content = (
        "The following is a concatenation of the log files produced.\n"
        "If a file is missing, it will be indicated.\n\n"
    )

    content += "---First, a chronological, high level log of the AIDE run---\n"
    content += output_file_or_placeholder(chrono_log) + "\n\n"

    content += "---Next, the ID of the best node(s) from the run---\n"
    for node_id_path in glob.glob(str(best_node)):
        content += output_file_or_placeholder(Path(node_id_path)) + "\n"
    content += "\n\n"

    content += "---Finally, the full journal of the run---\n"
    content += output_file_or_placeholder(journal) + "\n\n"

    return content


def output_file_or_placeholder(file: Path):
    if file.exists():
        if file.suffix != ".json":
            return file.read_text()
        else:
            return json.dumps(json.loads(file.read_text()), indent=4)
    else:
        return f"File not found."
